<?php
	session_start();
	error_reporting(0);
	include("config.php");
	include("functions.php");
	include("functions_mysql.php");
	if($_REQUEST['do']=="login")
	{
		$res = FetchData("select * from admin where username='".$_REQUEST['uname']."' and password='".$_REQUEST['upass']."'");
		if($res > 0)
		{
			echo $_SESSION['user_manufacturer']=$res['username'];
			header("location:home.php");
		}
		else
			echo '<script>alert("Username or Password is Wrong");location.href="signin.php";</script>';
		exit();
			
	}
	else if($_REQUEST['do']=="changepass")
	{
		if($_REQUEST['newpass']==$_REQUEST['confirmpass'])
		{
			$res = FetchData("select * from admin where username='".$_SESSION['user_manufacturer']."' and password='".$_REQUEST['oldpass']."'");
			if($res > 0)
			{	
				$FieldValue = array('password'=>'\''.addslashes($_REQUEST['newpass']).'\'');
				UpdateData('admin',$FieldValue, "username='".$_SESSION['user_manufacturer']."'");
				echo '<script>alert("Password Change Successfully");location.href="home.php";</script>';
				exit();
			}
			else
			{
				echo '<script>alert("Invalid Password");location.href="changepassword.php";</script>';
				exit();
			}
		}
		else
		{
			echo '<script>alert("New Password Not Match");location.href="changepassword.php";</script>';
			exit();
		}
	}
	else if($_REQUEST['do']=="logout")
	{
		 $_SESSION['user_manufacturer']="";
		 session_destroy();
		 header("location:signin.php");
	}
	else if($_REQUEST['do']=="deleteadimages")
	{
		if($_REQUEST['val'] == "0")
			$FieldValue = array('isactive'=>'\''."1".'\'');
		else if($_REQUEST['val'] == "1")
			$FieldValue = array('isactive'=>'\''."0".'\'');
		UpdateData('adsimg',$FieldValue, "id=".$_REQUEST['id']);
		header("location:adimages.php");
	}
	else if($_REQUEST['do']=="addimages")
	{
		$FieldValue = array('title'=>'\''.addslashes($_REQUEST['title']).'\''
							);
		$id=AddData('adsimg',$FieldValue);
		if (basename($_FILES['photo']['name']) != "" ) {
			$photo = UploadImage($_FILES['photo']['tmp_name'],"upload/",$id.".jpg");
		}
		header("location:adimages.php");
	}
	
	
	else if($_REQUEST['do']=="addparty")
	{
		$FieldValue = array('name'=>'\''.addslashes($_REQUEST['name']).'\'',
							'mobile'=>'\''.addslashes($_REQUEST['mobile']).'\'',
							'email'=>'\''.addslashes($_REQUEST['email']).'\'',
							'fax'=>'\''.addslashes($_REQUEST['fax']).'\'',
							'address'=>'\''.addslashes($_REQUEST['address']).'\'',
							'isActive'=>1);
		AddData('party',$FieldValue);
		header("location:party.php");
	}
	else if($_REQUEST['do']=="updateparty")
	{
		$FieldValue = array('name'=>'\''.addslashes($_REQUEST['name']).'\'',
							'mobile'=>'\''.addslashes($_REQUEST['mobile']).'\'',
							'email'=>'\''.addslashes($_REQUEST['email']).'\'',
							'fax'=>'\''.addslashes($_REQUEST['fax']).'\'',
							'address'=>'\''.addslashes($_REQUEST['address']).'\'',
							'isActive'=>1);
		UpdateData('party',$FieldValue, "id=".$_REQUEST['id']);
		header("location:party.php");
	}
	else if($_REQUEST['do']=="actionparty")
	{
		if($_REQUEST['val'] == "0")
			$FieldValue = array('isActive'=>'\''."1".'\'');
		else if($_REQUEST['val'] == "1")
			$FieldValue = array('isActive'=>'\''."0".'\'');
		UpdateData('party',$FieldValue, "id=".$_REQUEST['id']);
		header("location:party.php");
	}
	else if($_REQUEST['do']=="addtabuser")
	{
		$FieldValue = array('username'=>'\''.addslashes($_REQUEST['uname']).'\'',
							'password'=>'\''.addslashes($_REQUEST['pass']).'\'',
							'isActive'=>1);
		AddData('tab_user',$FieldValue);
		header("location:tabuser.php");
	}
	else if($_REQUEST['do']=="updatetabuser")
	{
		$FieldValue = array('username'=>'\''.addslashes($_REQUEST['uname']).'\'',
							'password'=>'\''.addslashes($_REQUEST['pass']).'\'',
							'isActive'=>1);
		UpdateData('tab_user',$FieldValue, "id=".$_REQUEST['id']);
		header("location:tabuser.php");
	}
	else if($_REQUEST['do']=="actiontabuser")
	{
		if($_REQUEST['val'] == "0")
			$FieldValue = array('isActive'=>'\''."1".'\'');
		else if($_REQUEST['val'] == "1")
			$FieldValue = array('isActive'=>'\''."0".'\'');
		UpdateData('tab_user',$FieldValue, "id=".$_REQUEST['id']);
		header("location:tabuser.php");
	}
	else if($_REQUEST['do']=="addcategory")
	{
		$FieldValue = array('name'=>'\''.addslashes($_REQUEST['name']).'\'',
							'type'=>'\''.addslashes($_REQUEST['type']).'\'',
							'isActive'=>1);
		AddData('category',$FieldValue);
		header("location:category.php");
	}
	else if($_REQUEST['do']=="updatecategory")
	{
		$FieldValue = array('name'=>'\''.addslashes($_REQUEST['name']).'\'',
							'type'=>'\''.addslashes($_REQUEST['type']).'\'',
							'isActive'=>1);
		UpdateData('category',$FieldValue, "id=".$_REQUEST['id']);
		header("location:category.php");
	}
	else if($_REQUEST['do']=="deletecategory")
	{
		if($_REQUEST['val'] == "0")
			$FieldValue = array('isActive'=>'\''."1".'\'');
		else if($_REQUEST['val'] == "1")
			$FieldValue = array('isActive'=>'\''."0".'\'');
		UpdateData('category',$FieldValue, "id=".$_REQUEST['id']);
		header("location:category.php");
	}
	else if($_REQUEST['do']=="getscat")
	{
		$res = FetchMultipleData("select * from sub_category where cid=".$_REQUEST["id"]);
		if(sizeof($res)>0){
		echo "<label>Sub Category</label>";
		echo "<select id='scategory' data-required='true' name='scategory' class='form-control m-t'>";
		echo "<option value=''>Select Sub Category</option>";
            
		for($j=0; $j<sizeof($res); $j++)
		{
			echo "<option value='".$res[$j]['id']."'>".$res[$j]['name']."</option>";
		}
                                
		echo "</select>";}
		else
		{ echo "";}
	}
	else if($_REQUEST['do']=="addscategory")
	{
		$FieldValue = array('name'=>'\''.addslashes($_REQUEST['name']).'\'',
							'cid'=>'\''.addslashes($_REQUEST['cid']).'\'',
							'isActive'=>1);
		AddData('sub_category',$FieldValue);
		header("location:sub_category.php?id=".$_REQUEST['cid']);
	}
	else if($_REQUEST['do']=="updatescategory")
	{
		$FieldValue = array('name'=>'\''.addslashes($_REQUEST['name']).'\'',
							'cid'=>'\''.addslashes($_REQUEST['cid']).'\'',
							'isActive'=>1);
		UpdateData('sub_category',$FieldValue, "id=".$_REQUEST['id']);
		header("location:category.php");
	}
	else if($_REQUEST['do']=="addstock")
	{
		
		$FieldValue = array('product_id'=>'\''.addslashes($_REQUEST['product']).'\'',
							'qty'=>'\''.addslashes($_REQUEST['qty']).'\'',
							'isActive'=>1);
		AddData('product_stock',$FieldValue);
		header("location:stock.php");
	}
	else if($_REQUEST['do']=="updatestock")
	{
		$FieldValue = array('qty'=>'\''.addslashes($_REQUEST['qty']).'\'',
							'isActive'=>1);
		UpdateData('product_stock',$FieldValue, "id=".$_REQUEST['id']);
		header("location:stock.php");
	}
	else if($_REQUEST['do']=="deletestock")
	{
		if($_REQUEST['val'] == "0")
			$FieldValue = array('isActive'=>'\''."1".'\'');
		else if($_REQUEST['val'] == "1")
			$FieldValue = array('isActive'=>'\''."0".'\'');
		UpdateData('product_stock',$FieldValue, "id=".$_REQUEST['id']);
		header("location:stock.php");
	}
	else if($_REQUEST['do']=="addproduct")
	{
		
		//$res = FetchData("select type from category where id=".$_REQUEST['category']);
		
		//$code="";
		//$mm="";
		//$type="";
		
		//if($res["type"] == 2)
		//{
			$mm='\''.addslashes($_REQUEST['mm']).'\'';
			$type='\''.addslashes($_REQUEST['type']).'\'';
		//}
		//else
		//{
			$code='\''.addslashes($_REQUEST['code']).'\'';
		//}
		
		$FieldValue = array('code'=>$code,
							'dispCode'=>'\''.addslashes($_REQUEST['dcode']).'\'',
							'rateType'=>'\''.addslashes($_REQUEST['rateType']).'\'',
							'rate'=>'\''.addslashes($_REQUEST['rate']).'\'',
							'catid'=>'\''.addslashes($_REQUEST['category']).'\'',
							'partyid'=>'\''.addslashes($_REQUEST['party']).'\'',
							'sizeTypeW'=>'\''.addslashes($_REQUEST['sizeTypeW']).'\'',
							'sizeW'=>'\''.addslashes($_REQUEST['sizeW']).'\'',
							'sizeTypeH'=>'\''.addslashes($_REQUEST['sizeTypeH']).'\'',
							'sizeH'=>'\''.addslashes($_REQUEST['sizeH']).'\'',
							'mm'=>$mm,
							'type'=>$type,
							'isActive'=>1);
		$id=AddData('product',$FieldValue);
		if (basename($_FILES['photo']['name']) != "" ) {
			$photo = UploadImage($_FILES['photo']['tmp_name'],"upload/",$id.".jpg");
		}	
		header("location:product.php");
	}
	else if($_REQUEST['do']=="updateproduct")
	{	
		//$res = FetchData("select type from category where id=".$_REQUEST['category']);
		
		//$code="";
		//$mm="";
		//$type="";
		
		//echo $res["type"];
		
		//if($res["type"] == 2)
		//{
			$mm='\''.addslashes($_REQUEST['mm']).'\'';
			$type='\''.addslashes($_REQUEST['type']).'\'';
		//}
		//else
		//{
			$code='\''.addslashes($_REQUEST['code']).'\'';
		//}
		
		$FieldValue = array('code'=>$code,
							'dispCode'=>'\''.addslashes($_REQUEST['dcode']).'\'',
							'rateType'=>'\''.addslashes($_REQUEST['rateType']).'\'',
							'rate'=>'\''.addslashes($_REQUEST['rate']).'\'',
							'catid'=>'\''.addslashes($_REQUEST['category']).'\'',
							'partyid'=>'\''.addslashes($_REQUEST['party']).'\'',
							'sizeTypeW'=>'\''.addslashes($_REQUEST['sizeTypeW']).'\'',
							'sizeW'=>'\''.addslashes($_REQUEST['sizeW']).'\'',
							'sizeTypeH'=>'\''.addslashes($_REQUEST['sizeTypeH']).'\'',
							'sizeH'=>'\''.addslashes($_REQUEST['sizeH']).'\'',
							'mm'=>$mm,
							'type'=>$type,
							'isActive'=>1);
		UpdateData('product',$FieldValue, "id=".$_REQUEST['id']);
		if (basename($_FILES['photo']['name']) != "" ) {
			$photo = UploadImage($_FILES['photo']['tmp_name'],"upload/",$_REQUEST['id'].".jpg");
		}	
		header("location:product.php");
	}
	else if($_REQUEST['do']=="deleteproduct")
	{
		if($_REQUEST['val'] == "0")
			$FieldValue = array('isActive'=>'\''."1".'\'');
		else if($_REQUEST['val'] == "1")
			$FieldValue = array('isActive'=>'\''."0".'\'');
		UpdateData('product',$FieldValue, "id=".$_REQUEST['id']);
		header("location:product.php");
	}
	else if($_REQUEST['do']=="getproducts")
	{
		$res = FetchMultipleData("select * from product where isActive=1 and catid=".$_REQUEST["id"]);
		if(sizeof($res)>0){
		echo "<option value=''>Select Product</option>";
            
		for($j=0; $j<sizeof($res); $j++)
		{
			echo "<option value='".$res[$j]['id']."'>".$res[$j]['dispCode']." (Price : ".$res[$j]['rate'].")"."</option>";
		}
                                
		}
		else
		{ echo "";}
	}
	else if($_REQUEST['do']=="confirmorder")
	{
		$FieldValue = array('isComplete'=>'\''."1".'\'');
		UpdateData('order_bill',$FieldValue, "id=".$_REQUEST['id']);	
		if($_REQUEST['home']==1)
			header("location:home.php");
		else
			header("location:order.php");
	}
	else if($_REQUEST['do']=="deletequatation")
	{
		if($_REQUEST['val'] == "0")
			$FieldValue = array('isActive'=>'\''."1".'\'');
		else if($_REQUEST['val'] == "1")
			$FieldValue = array('isActive'=>'\''."0".'\'');
		UpdateData('order_bill',$FieldValue, "id=".$_REQUEST['id']);	
		if($_REQUEST['home']==1)
			header("location:home.php");
		else
			header("location:quatation.php");
	}
	else if($_REQUEST['do']=="deleteorder")
	{
		if($_REQUEST['val'] == "0")
			$FieldValue = array('isActive'=>'\''."1".'\'');
		else if($_REQUEST['val'] == "1")
			$FieldValue = array('isActive'=>'\''."0".'\'');
		UpdateData('order_bill',$FieldValue, "id=".$_REQUEST['id']);	
		if($_REQUEST['home']==1)
			header("location:home.php");
		else
			header("location:order.php");
	}
	else if($_REQUEST['do']=="repeteorder")
	{
		$orderData = FetchData("select * from order_bill where id=".$_REQUEST["id"]);
		//print_r($orderData);
		
		$FieldValue = array('custid'=>'\''.addslashes($orderData['custid']).'\'',
							'quatationDate'=>'\''.date("Y-m-d H:i:s").'\'',
							'orderDate'=>'\''.date("Y-m-d H:i:s").'\'',
							'address1'=>'\''.addslashes($orderData['address1']).'\'',
							'address2'=>'\''.addslashes($orderData['address2']).'\'',
							'arc'=>'\''.addslashes($orderData['arc']).'\'',
							'arcmo'=>'\''.addslashes($orderData['arcmo']).'\'',
							'krp'=>'\''.addslashes($orderData['krp']).'\'',
							'krpmo'=>'\''.addslashes($orderData['krpmo']).'\'',
							'employee_name'=>'\''.addslashes($orderData['employee_name']).'\'',
							'isQuatation'=>1,
							'isComplete'=>0,
							'isExported'=>0,
							'isActive'=>1);
		$newBillId=AddData('order_bill',$FieldValue);
		
		$itemsData = FetchMultipleData("select * from order_item where billid=".$_REQUEST["id"]);
		
		for($j=0; $j<sizeof($itemsData); $j++)
		{
			
			$itemData = FetchData("select * from order_item where id=".$itemsData[$j]["id"]);
			
			$FieldValue = array('billid'=>'\''.addslashes($newBillId).'\'',
					'prodid'=>'\''.addslashes($itemData['prodid']).'\'',
					'rate'=>'\''.addslashes($itemData['rate']).'\'',
					'qty'=>'\''.addslashes($itemData['qty']).'\'',		
                    'remark'=>'\''.addslashes($itemData['remark']).'\'');
                   
			AddData("order_item",$FieldValue);
		}
		header("location:viewquatation.php?id=".$newBillId);
	}
	else if($_REQUEST['do']=="addbillitem")
	{
		$FieldValue = array('billid'=>'\''.addslashes($_REQUEST['quatation_id']).'\'',
					'prodid'=>'\''.addslashes($_REQUEST['product']).'\'',
					'rate'=>'\''.addslashes($_REQUEST['rate']).'\'',
					'qty'=>'\''.addslashes($_REQUEST['qty']).'\'',		
                    'remark'=>'\''.addslashes($_REQUEST['remark']).'\'');
                   
		AddData("order_item",$FieldValue);
		header("location:viewquatation.php?id=".$_REQUEST['quatation_id']);
	}
	else if($_REQUEST['do']=="confirmquatation")
	{	
		$cnt = 0;
		$parties;
		
		$price = $_REQUEST["price"];
		$txt = $_REQUEST["txt"];
		$ids = $_REQUEST["ids"];
		foreach($_REQUEST["chk"] as $key => $value)
		{
			$FieldValue = array('qty'=>'\''.$txt[$value].'\'',
						'rate'=>'\''.$price[$value].'\'',
						'isActive'=>'\''."1".'\'');
			
			UpdateData('order_item',$FieldValue, "id=".$ids[$value]);
			
			$pid = FetchData("select billid,prodid from order_item where id=".$ids[$value]);

			$FieldValue = array('product_id'=>'\''.$pid["prodid"].'\'',
							'qty'=>'\''.$txt[$value].'\'',
							'isActive'=>1);
			AddData('sell_stock',$FieldValue);

			$mailids = FetchData("select p.id, p.email, p.mobile, d.code, d.type from party p join product d on p.id=d.partyid where d.id=".$pid["prodid"]);
			
			$params = "";	
			$params["mailto"] = $mailids["email"];
			$strCode = "";
			if($mailids["code"] != "")
			{
				$strCode = $mailids["code"];
			}
			else
			{
				$strCode = $mailids["type"];
			}
			$params["message"] = "Please Send ".$txt[$value]." Items of Product Code/Type is ".$strCode." to OASIS and Mention voucher number ".$pid["billid"];
			
			if(array_key_exists($mailids["mobile"], $parties))
			{
				$parties[$mailids["mobile"]] = $parties[$mailids["mobile"]].",".$strCode."(Qty:".$txt[$value].")";
			}
			else
			{
				$parties[$mailids["mobile"]] = $strCode."(Qty:".$txt[$value].")";
			}
			
			
			/*$ch1 = curl_init("http://admin.bulksmslogin.com/api/sendhttp.php");
			$params = "";	
			$params["authkey"] = "76580AmkyO1iai54a13d0c";
			$params["mobiles"] = $mailids["mobile"];
			$params["message"]= "Please Send ".$txt[$value]." Items of Product Code/Type is ".$strCode." to OASIS and Mention voucher number ".$pid["billid"];
			$params["sender"]="OASISI";
			$params["route"]=2;
			
			$postData = '';
			foreach($params as $k => $v) 
			{ 
				$postData .= $k . '='.$v.'&'; 
			}
			rtrim($postData, '&');
			
			curl_setopt($ch1,CURLOPT_RETURNTRANSFER,true);
			curl_setopt($ch1,CURLOPT_HEADER, false); 
			curl_setopt($ch1, CURLOPT_POSTFIELDS, $postData);  
			//$output = curl_exec($ch1);
			//print_r($output);
			curl_close($ch1);*/
			
			/*
			$userD = FetchData("select c.mobile from customer c join order_bill o on c.id=o.custid where o.id=".$pid["billid"]);
			
			$ch1 = curl_init("http://admin.bulksmslogin.com/api/sendhttp.php");
			$params = "";	
			$params["authkey"] = "76580AmkyO1iai54a13d0c";
			$params["mobiles"] = $userD["mobile"];
			$params["message"]= "Thank you for visiting OASIS Interior Hub.";
			$params["sender"]="OASISI";
			$params["route"]=2;
			
			$postData = '';
			foreach($params as $k => $v) 
			{ 
				$postData .= $k . '='.$v.'&'; 
			}
			rtrim($postData, '&');
			
			curl_setopt($ch1,CURLOPT_RETURNTRANSFER,true);
			curl_setopt($ch1,CURLOPT_HEADER, false); 
			curl_setopt($ch1, CURLOPT_POSTFIELDS, $postData);  
			//$output = curl_exec($ch1);
			//print_r($output);
			curl_close($ch1);*/
			
			//echo $txt[$value]."-".$ids[$value]."<br>";
		}
	
		//print_r($parties);
		
		$parties["8000672007"] = "Quatation Confirm";
		
		$lastBillNo = FetchData("select max(billNo) as billNo from order_bill");
		
		$FieldValue = array('billNo'=>'\''.($lastBillNo["billNo"]+1).'\'',
				'isQuatation'=>'\''."0".'\'',
				'orderDate'=>'\''.date("Y-m-d H:i:s").'\'');
		UpdateData('order_bill',$FieldValue, "id=".$_REQUEST['orderId']);	
		
		foreach($parties as $key => $value)
		{
			$postData = '';
		
			foreach($params as $k => $v) 
			{ 
				$postData .= $k . '='.$v.'&'; 
			}
			rtrim($postData, '&');
			
			$ch = curl_init("http://admin.bulksmslogin.com/api/sendhttp.php");
			
			//echo "<br>".$value;
			
			$params = "";	
			$params["authkey"] = "76580AmkyO1iai54a13d0c";
			$params["mobiles"] = $key;
			$params["message"]= "Please Send ".$value." Items to OASIS and Mention voucher number ".($lastBillNo["billNo"]+1);
			$params["sender"]="OASISI";
			$params["route"]=2;
			
			curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
			curl_setopt($ch,CURLOPT_HEADER, false); 
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);  
			$output = curl_exec($ch);
			//echo "<br>";
			//print_r($output);
		}
		curl_close($ch);
		
		//echo '<script>alert("Quatation Successfully Confirm");</script>';
		echo '<script>location.href="order.php";</script>';
		exit();
	}
	else if($_REQUEST['do']=="updatecustomer")
	{
		$FieldValue = array('name'=>'\''.addslashes($_REQUEST['name']).'\'',
							'email'=>'\''.addslashes($_REQUEST['email']).'\'',
							'mobile'=>'\''.addslashes($_REQUEST['mobile']).'\'',
							'address1'=>'\''.addslashes($_REQUEST['address1']).'\'',
							'address2'=>'\''.addslashes($_REQUEST['address2']).'\'');
		UpdateData('customer',$FieldValue, "id=".$_REQUEST['id']);
		header("location:customer.php");
	}
	else if($_REQUEST['do']=="sentdispatchmsg")
	{
		$ch = curl_init("http://admin.bulksmslogin.com/api/sendhttp.php");
		$params = "";	
		$params["authkey"] = "76580AmkyO1iai54a13d0c";
		$params["mobiles"] = $_REQUEST['mobile'];
		$params["message"]= "Your order is dispatched from OASIS Interior Hub.";
		$params["sender"]="OASISI";
		$params["route"]=2;
		
		$postData = '';
		foreach($params as $k => $v) 
		{ 
			$postData .= $k . '='.$v.'&'; 
		}
		rtrim($postData, '&');
		
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);  
		//$output = curl_exec($ch);
		//print_r($output);
		curl_close($ch);
		
		$FieldValue = array('isExported'=>'\''."1".'\'');
		UpdateData('order_bill',$FieldValue, "id=".$_REQUEST['billno']);	
		
	}
?>
