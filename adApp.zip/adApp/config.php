<?php
	error_reporting(0);
	define("DB_HOST", "mysql.hostinger.my");
	define("DB_USER", "u477276124_adapp");
	define("DB_PASSWORD", "julfikar123!");
	define("DB_DATABASE", "u477276124_adapp");
	$con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD) or die("Conenction Error");
	mysql_select_db(DB_DATABASE) or die("DB Error");
?>
