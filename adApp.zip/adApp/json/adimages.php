<?php
    header('Content-type: application/json');
    include "../config.php";
    include "../functions_mysql.php";
    if($_REQUEST['scatid'])
		$scatid = $_REQUEST['scatid'];
	else
		$scatid = 0;
	$query="select * from adsimg where isactive=1";
    $result=FetchMultipleData($query);
    $res1="";
		if(sizeof($result)>0){
			for($i=0; $i<sizeof($result); $i++)
			{
				$res["sr"]=($i+1);
				$res["title"]=$result[$i]['title'];
                
                //$res["edit"]="<a href='editcategory.php?id=".$result[$i]['id']."' class='active'>";
                //$res["edit"].="<i class='fa fa-edit text-primary text-active'></i></a>";
          
                $res["delete"]="<a href='action.php?do=deleteadimages&id=".$result[$i]['id']."&val=".$result[$i]['isactive']."' class='active'>";
                if($result[$i]['isActive'] == 0)
                    $res["delete"].="<i class='fa fa-check text-success text-active'></i></a>";
                else
                    $res["delete"].="<i class='fa fa-times text-danger text-active'></i></a>";
				$res1[]=$res;
			}
            echo $res = json_encode(array("aaData"=>$res1));
        }
        else
		{	
			echo $res = json_encode(array("aaData"=>$res1));
        }
?>
