<?php
    header('Content-type: application/json');
    include "../config.php";
    include "../functions_mysql.php";
    
	$query="select c.*,a.title from adscnt c join adsimg a on c.adid=a.id order by c.id desc";
    $result=FetchMultipleData($query);
    $res1="";
		if(sizeof($result)>0){
			for($i=0; $i<sizeof($result); $i++)
			{
				$res["sr"]=($i+1);
				$res["deviceid"]=$result[$i]['deviceid'];
                $res["time"]=$result[$i]['datetime'];
                $res["ads"]=$result[$i]['title'];
                
				$res1[]=$res;
			}
            echo $res = json_encode(array("aaData"=>$res1));
        }
        else
		{	
			echo $res = json_encode(array("aaData"=>$res1));
        }
?>
