<?php
function Connect($db_hostname,$db_username,$db_password,$db_dbname) {
	if ( !$link = mysql_connect($db_hostname,$db_username,$db_password) ) {
		die(mysql_error());
	}
	if ( !mysql_select_db($db_dbname,$link) ) {
		die(mysql_error());
	}
}
function AddData($tablename,$dataArray) {
		$sql = "insert into ".$tablename." set ";
		foreach($dataArray as $key=>$value) {
			$sql .= $key."=".$value.",";
		}
		$sql = trim($sql,",");
		$rs = mysql_query($sql) or die($sql."<hr>".mysql_error());
		return mysql_insert_id();
}

function UpdateData($tablename,$dataArray,$condition) {
	$sql = "update ".$tablename." set ";
	foreach($dataArray as $key=>$value) {
		$sql .= $key."=".$value.",";
	}
	$sql = trim($sql,",");
	$sql .= " where ".$condition;
	$rs = mysql_query($sql) or die($sql."<hr>".mysql_error());
}
function DeleteData($tablename,$condition) {
	$sql = "delete from ".$tablename." where ".$condition;
	$rs = mysql_query($sql) or die($sql."<hr>".mysql_error());
}
function rowCount($sql='') {
	$rs = mysql_query($sql) or die($sql."<hr>".mysql_error());
	return mysql_num_rows($rs);
}
function FetchData($sql='') {
	$rs = mysql_query($sql) or die($sql."<hr>".mysql_error());
	$row = mysql_fetch_array($rs);
	return $row;
}
function FetchMultipleData($sql='') {
	$rs = mysql_query($sql) or die($sql."<hr>".mysql_error());
	if(mysql_num_rows($rs) > 0)
	{
		while ( $row = mysql_fetch_array($rs) ) {
			$data[] = $row;
		}
	}
	return $data;
}
function getTableData($tablename,$condition) {
	$sql = "select * from ".$tablename." where ".$condition;
	$rs = mysql_query($sql) or die($sql."<hr>".mysql_error());
	$row = mysql_fetch_array($rs);
	return $row;
}

function IsLoggedIn() {
	if ( $_SESSION['UserID'] != "" ) {
		return true;	
	} else {
		return false;	
	}
}
function NumberOfRows($sql) {
	$rs = mysql_query($sql);
	if( !$rs ){
		echo $sql."<hr>".mysql_error();
		exit();
	} else {
		$numrows = mysql_num_rows($rs);		
	}
	return $numrows;
}
function SearchResultSort($query,$fieldname='',$sorting='asc',$limit='0, 10') {
	if($fieldname!="" && $sorting!=""){
		$fieldname1=" order by ".$fieldname." ".$sorting;
	}
	if($limit!=""){
		$limit1=" limit ".$limit;
	}
	$sql = $query.$fieldname1.$limit1;
	$record=FetchMultipleData($sql);
	return $record;
}
function sendNotificationToIos($message,$deviceToken)
{
    $passphrase = 'Agile';
        ////////////////////////////////////////////////////////////////////////////////
    
    $ctx = stream_context_create();
    stream_context_set_option($ctx, 'ssl', 'local_cert', 'ws/ck.pem');
    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
  // stream_context_set_option($ctx, 'ssl', 'cafile', 'entrust_2048_ca.cer');
    
    
    $fp = stream_socket_client(
                               'ssl://gateway.sandbox.push.apple.com:2195', $err,
                               $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
   /*
    if (!$fp)
        exit("Failed to connect: $err $errstr" . PHP_EOL);
    
    echo 'Connected to APNS' . PHP_EOL;
    */
    $body['aps'] = array(
                         'alert' => $message,
                         'sound' => 'default'
                         );
    
    
    $payload = json_encode($body);
    $msg="";
    // Build the binary notification
    foreach($deviceToken as $token){
        $msg .= chr(0) . pack('n', 32) . pack('H*', $token) . pack('n', strlen($payload)) . $payload;
    }
    // Send it to the server
    $result = fwrite($fp, $msg, strlen($msg));
    /*
    if (!$result)
        echo 'Message not delivered' . PHP_EOL;
    else
        echo 'Message successfully delivered' . PHP_EOL;
    
    // Close the connection to the server
     */
    fclose($fp);

}
?>
