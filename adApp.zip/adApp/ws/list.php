<?php
	include "config.php";
	include "functions_mysql.php";
?>
<!DOCTYPE html>
<html>
<head>
        <title>Users</title>
        
		
 </head>
    <body class="page-header-fixed compact-menu page-horizontal-bar">
         		
              
                                   <div class="table-responsive">
                                    <table id="example" class="display table" style="width: 100%; cellspacing: 0;" border=1>
                                        <thead>
                                            <tr>
												<th>Sr.</th>
                                                <th>Device Id</th>
                                                <th>Time</th>
                                                <th>Ad Id</th>
                                            </tr>
                                        </thead>
                                         <?php
										$res = FetchMultipleData("select * from adscnt order by id desc");
										
									?>
                                        <tbody>
										 <?php
												for($i=0; $i<sizeof($res); $i++)
												{
													echo "<tr><td>".($i+1)."</td>";
													echo "<td>".$res[$i]['deviceid']."</td>";
													echo "<td>".date('d M, y h:i a', strtotime($res[$i]['datetime']))."</td>";
													echo "<td>".$res[$i]['adid']."</td>";
													echo "</tr>";
												}
											?>
										
                                           
                                        </tbody>
                                       </table>  
                                   
            </div><!-- Page Inner -->
  </body>    
 
</html>
