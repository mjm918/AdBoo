<?php 
    header('Content-type: application/json; charset=utf-8');
    error_reporting(0);
    include "config.php";
    
    foreach ($_REQUEST['index'] as $key => $value) {
		mysql_query("insert into adscnt (deviceid, adid, datetime) values ('".
			$_REQUEST['uid']."', '".$value."','".$_REQUEST['time'][$key]."')");
	}
	
	$arr = array('success' => 1,'uid' => $_REQUEST['uid'], 'index' => $_REQUEST['index'],'time' => $_REQUEST['time']);
		
	echo json_encode($arr);		
?>

