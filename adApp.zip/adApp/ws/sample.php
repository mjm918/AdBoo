<?php 
    header('Content-type: application/json; charset=utf-8');
    error_reporting(0);
    include "../config.php";
	include "../functions_mysql.php";
    
    if($_REQUEST["index"]==0)
		$result=FetchData("select * from adsimg order by id asc limit 0,1");
	else
	{
		$result=FetchData("select * from adsimg where id>".$_REQUEST['index']." order by id asc limit 0,1");
		if(!$result)
		{
			$result=FetchData("select * from adsimg order by id asc limit 0,1");
		}
	}
	date_default_timezone_set('Asia/Kualalumpur');
	
	mysql_query("insert into adscnt (deviceid, adid, datetime) values ('".
		$_REQUEST['uid']."', '".$result["id"]."','".date('Y-m-d H:i:s')."')");
	
	$arr = array('success' => 1 ,'url' => "ftp://julfikar.16mb.com/adApp/upload/".$result["id"].".jpg", 'index' => $result["id"]);
		
	echo json_encode($arr);		
?>

