<?php
function getCountryOption($selected_country) {
			$country = array("United States"=>"United States","United Kingdom"=>"United Kingdom","Canada"=>"Canada","Australia"=>"Australia","Afghanistan"=>"Afghanistan","Albania"=>"Albania","Algeria"=>"Algeria","American Samoa"=>"American Samoa","Andorra"=>"Andorra","Angola"=>"Angola","Anguilla"=>"Anguilla","Antarctica"=>"Antarctica","Antigua &amp; Barbuda"=>"Antigua &amp; Barbuda","Argentina"=>"Argentina","Armenia"=>"Armenia","Aruba"=>"Aruba","Austria"=>"Austria","Azerbaijan"=>"Azerbaijan","Bahamas"=>"Bahamas","Bahrain"=>"Bahrain","Bangladesh"=>"Bangladesh","Barbados"=>"Barbados","Belarus"=>"Belarus","Belgium"=>"Belgium","Belize"=>"Belize","Benin"=>"Benin","Bermuda"=>"Bermuda","Bhutan"=>"Bhutan","Bolivia"=>"Bolivia","Bosnia &amp; Herzegowina"=>"Bosnia &amp; Herzegowina","Bouvet Island"=>"Bouvet Island","British Indian Ocean Ter."=>"British Indian Ocean Ter.","Brunei Darussalam"=>"Brunei Darussalam","Bulgaria"=>"Bulgaria","Burkina Faso"=>"Burkina Faso","Burundi"=>"Burundi","Cambodia"=>"Cambodia","Cameroon"=>"Cameroon","Cape Verde"=>"Cape Verde","Cayman Islands"=>"Cayman Islands","Central African Rep."=>"Central African Rep.","Chad"=>"Chad","Chile"=>"Chile","China"=>"China","Christmas Island"=>"Christmas Island","Cocos (Keeling) Islands"=>"Cocos (Keeling) Islands","Colombia"=>"Colombia","Comoros"=>"Comoros","Congo"=>"Congo","Cook Islands"=>"Cook Islands","Costa Rica"=>"Costa Rica","Cote D'ivoire"=>"Cote D'ivoire","Croatia"=>"Croatia","Cuba"=>"Cuba","Cyprus"=>"Cyprus","Czech Republic"=>"Czech Republic","Denmark"=>"Denmark","Djibouti"=>"Djibouti","Dominica"=>"Dominica","Dominican Republic"=>"Dominican Republic","East Timor"=>"East Timor","Ecuador"=>"Ecuador","Egypt"=>"Egypt","El Salvador"=>"El Salvador","Equatorial Guinea"=>"Equatorial Guinea","Eritrea"=>"Eritrea","Estonia"=>"Estonia","Ethiopia"=>"Ethiopia","Falkland Islands"=>"Falkland Islands","Faroe Islands"=>"Faroe Islands","Fiji"=>"Fiji","Finland"=>"Finland","France"=>"France","France, Metropolitan"=>"France, Metropolitan","French Guiana"=>"French Guiana","French Polynesia"=>"French Polynesia","French Southern Ter."=>"French Southern Ter.","Gabon"=>"Gabon","Gambia"=>"Gambia","Georgia"=>"Georgia","Germany"=>"Germany","Ghana"=>"Ghana","Gibraltar"=>"Gibraltar","Greece"=>"Greece","Greenland"=>"Greenland","Grenada"=>"Grenada","Guadeloupe"=>"Guadeloupe","Guam"=>"Guam","Guatemala"=>"Guatemala","Guinea"=>"Guinea","Guinea-Bissau"=>"Guinea-Bissau","Guyana"=>"Guyana","Haiti"=>"Haiti","Heard &amp; McDonald Isl."=>"Heard &amp; McDonald Isl.","Holy See (Vatican City)"=>"Holy See (Vatican City)","Honduras"=>"Honduras","Hong Kong"=>"Hong Kong","Hungary"=>"Hungary","Iceland"=>"Iceland","India"=>"India","Indonesia"=>"Indonesia","Iran"=>"Iran","Iraq"=>"Iraq","Ireland"=>"Ireland","Israel"=>"Israel","Italy"=>"Italy","Jamaica"=>"Jamaica","Japan"=>"Japan","Jordan"=>"Jordan","Kazakhstan"=>"Kazakhstan","Kenya"=>"Kenya","Kiribati"=>"Kiribati","Korea (North)"=>"Korea (North)","Korea (South)"=>"Korea (South)","Kuwait"=>"Kuwait","Kyrgyzstan"=>"Kyrgyzstan","Lao"=>"Lao","Latvia"=>"Latvia","Lebanon"=>"Lebanon","Lesotho"=>"Lesotho","Liberia"=>"Liberia","Libyan Arab Jamahiriya"=>"Libyan Arab Jamahiriya","Liechtenstein"=>"Liechtenstein","Lithuania"=>"Lithuania","Luxembourg"=>"Luxembourg","Macau"=>"Macau","Macedonia"=>"Macedonia","Madagascar"=>"Madagascar","Malawi"=>"Malawi","Malaysia"=>"Malaysia","Maldives"=>"Maldives","Mali"=>"Mali","Malta"=>"Malta","Marshall Islands"=>"Marshall Islands","Martinique"=>"Martinique","Mauritania"=>"Mauritania","Mauritius"=>"Mauritius","Mayotte"=>"Mayotte","Mexico"=>"Mexico","Micronesia"=>"Micronesia","Moldova"=>"Moldova","Monaco"=>"Monaco","Mongolia"=>"Mongolia","Montserrat"=>"Montserrat","Morocco"=>"Morocco","Mozambique"=>"Mozambique","Myanmar"=>"Myanmar","Namibia"=>"Namibia","Nauru"=>"Nauru","Nepal"=>"Nepal","Netherlands"=>"Netherlands","Netherlands Antilles"=>"Netherlands Antilles","New Caledonia"=>"New Caledonia","New Zealand"=>"New Zealand","Nicaragua"=>"Nicaragua","Niger"=>"Niger","Nigeria"=>"Nigeria","Niue"=>"Niue","Norfolk Island"=>"Norfolk Island","Northern Mariana Isl."=>"Northern Mariana Isl.","Norway"=>"Norway","Oman"=>"Oman","Pakistan"=>"Pakistan","Palau"=>"Palau","Panama"=>"Panama","Paraguay"=>"Paraguay","Peru"=>"Peru","Philippines"=>"Philippines","Pitcairn"=>"Pitcairn","Poland"=>"Poland","Portugal"=>"Portugal","Puerto Rico"=>"Puerto Rico","Qatar"=>"Qatar","Reunion"=>"Reunion","Romania"=>"Romania","Russian Federation"=>"Russian Federation","Rwanda"=>"Rwanda","St. Kitts &amp; Nevis"=>"St. Kitts &amp; Nevis","St. Lucia"=>"St. Lucia","St. Vincent &amp; Grenadines"=>"St. Vincent &amp; Grenadines","Samoa"=>"Samoa","San Marino"=>"San Marino","Sao Tome &amp; Principe"=>"Sao Tome &amp; Principe","Saudi Arabia"=>"Saudi Arabia","Senegal"=>"Senegal","Seychelles"=>"Seychelles","Sierra Leone"=>"Sierra Leone","Singapore"=>"Singapore","Slovakia"=>"Slovakia","Slovenia"=>"Slovenia","Solomon Islands"=>"Solomon Islands","Somalia"=>"Somalia","South Africa"=>"South Africa","South Georgia"=>"South Georgia","Spain"=>"Spain","Sri Lanka"=>"Sri Lanka","St. Helena"=>"St. Helena","St. Pierre &amp; Miquelon"=>"St. Pierre &amp; Miquelon","Sudan"=>"Sudan","Suriname"=>"Suriname","Svalbard &amp; Jan Mayen Isl."=>"Svalbard &amp; Jan Mayen Isl.","Swaziland"=>"Swaziland","Sweden"=>"Sweden","Switzerland"=>"Switzerland","Syrian Arab Republic"=>"Syrian Arab Republic","Taiwan"=>"Taiwan","Tajikistan"=>"Tajikistan","Tanzania"=>"Tanzania","Thailand"=>"Thailand","Togo"=>"Togo","Tokelau"=>"Tokelau","Tonga"=>"Tonga","Trinidad &amp; Tobago"=>"Trinidad &amp; Tobago","Tunisia"=>"Tunisia","Turkey"=>"Turkey","Turkmenistan"=>"Turkmenistan","Turks &amp; Caicos Islands"=>"Turks &amp; Caicos Islands","Tuvalu"=>"Tuvalu","Uganda"=>"Uganda","Ukraine"=>"Ukraine","United Arab Emirates"=>"United Arab Emirates","US Minor Outlying Isl."=>"US Minor Outlying Isl.","Uruguay"=>"Uruguay","Uzbekistan"=>"Uzbekistan","Vanuatu"=>"Vanuatu","Venezuela"=>"Venezuela","Vietnam"=>"Vietnam","Virgin Islands (British)"=>"Virgin Islands (British)","Virgin Islands (U.S.)"=>"Virgin Islands (U.S.)","Wallis &amp; Futuna Islands"=>"Wallis &amp; Futuna Islands","Western Sahara"=>"Western Sahara","Yemen"=>"Yemen","Yugoslavia"=>"Yugoslavia","Zaire"=>"Zaire","Zambia"=>"Zambia","Zimbabwe"=>"Zimbabwe");
				 foreach($country as $key=>$value){
					$option .= "<option ";
					$option .= " value=\"".$value."\"";
					if ( $selected_country == $value ) {
						$option .= " selected";
					}
					$option .= " >";
					$option .= $key;
					$option .= "</option>";
				}
		return $option;
}
function checkSession() {
	if ( $_SESSION['UserID'] == "" ) {
		return false;
	}
	return true;
}
function paginations($page,$total,$limit,$current_page,$extra=''){
	$ss = split("&",$extra);
	for($i=0;$i<count($ss);$i++ ) 
	{
		list($val1,$val2) = explode("=",$ss[$i]);
		if ( $val1 != "page_num"  ) {
			$qstring .= "&".$ss[$i];	
		} 
	 }	
	 $extra_page = $qstring;	
	$numofpages= ceil($total / $limit);
	if($numofpages > '1'){
		
		$range= 5;
		$range_min= ($range % 2 == 0)?($range / 2) - 1:($range - 1) / 2;
		$range_max= ($range % 2 == 0)?$range_min + 1:$range_min;
		$page_min= $current_page - $range_min;
		$page_max= $current_page + $range_max;
		
		$page_min= ($page_min < 1)?1:$page_min;
		$page_max= ($page_max < ($page_min + $range - 1))?$page_min + $range - 1:$page_max;
		if($page_max > $numofpages){
			$page_min= ($page_min > 1)?$numofpages - $range + 1:1;
			$page_max= $numofpages;
		}
		
		$page_min= ($page_min < 1)?1:$page_min;
		
		if( !empty($extra_page)){
			$extra_p=$extra_page;
		}
		
		$_SERVER['REDIRECT_URL']= $page; //clean the extra / if needed
		

		if(($current_page > ($range - $range_min)) && ($numofpages > $range)){
			
		}
		
		if($current_page > 1){
//			For Previous
		$page_pagination.= '<a class="page" href="' . $_SERVER['REDIRECT_URL'] . '?page_num=' . ($current_page - 1) . $extra_p . '">Previous</a> ';
		}
		
		for($i= $page_min;$i <= $page_max;$i++){
			if($i == $current_page)
				$page_pagination.= '<span class="current"><strong>' . $i . '</strong></span> ';
			else
				$page_pagination.= '<a class="page" href="' . $_SERVER['REDIRECT_URL'] . '?page_num=' . $i . $extra_p . '">' . $i . '</a> ';
		}
		
		if($current_page < $numofpages){
			// For Next
		$page_pagination.= ' <a class="page" href="' . $_SERVER['REDIRECT_URL'] . '?page_num=' . ($current_page + 1) . $extra_p . '">Next</a>';
		}
		
		if(($current_page < ($numofpages - $range_max)) && ($numofpages > $range)){
			//$page_pagination.= ' <a class="num" title="Last" href="' . $_SERVER['REDIRECT_URL'] . '&start=' . ($numofpages - 1) . $extra_p . '">&gt;</a> ';
		}
		return $page_pagination;
	} //end if more than 1 page
}

function paginations123($page,$total,$limit,$current_page,$extra=''){
	$ss = split("&",$extra);
	for($i=0;$i<count($ss);$i++ ) 
	{
		list($val1,$val2) = explode("=",$ss[$i]);
		if ( $val1 != "page_num"  ) {
			$qstring .= "&".$ss[$i];	
		} 
	 }	
	 $extra_page = $qstring;	
	$numofpages= ceil($total / $limit);
	if($numofpages > '1'){
		
		$range= 5;
		$range_min= ($range % 2 == 0)?($range / 2) - 1:($range - 1) / 2;
		$range_max= ($range % 2 == 0)?$range_min + 1:$range_min;
		$page_min= $current_page - $range_min;
		$page_max= $current_page + $range_max;
		
		$page_min= ($page_min < 1)?1:$page_min;
		$page_max= ($page_max < ($page_min + $range - 1))?$page_min + $range - 1:$page_max;
		if($page_max > $numofpages){
			$page_min= ($page_min > 1)?$numofpages - $range + 1:1;
			$page_max= $numofpages;
		}
		
		$page_min= ($page_min < 1)?1:$page_min;
		
		if( !empty($extra_page)){
			$extra_p=$extra_page;
		}
		
		$_SERVER['REDIRECT_URL']= $page; //clean the extra / if needed
		

		if(($current_page > ($range - $range_min)) && ($numofpages > $range)){
			
		}
		
		if($current_page < $numofpages){
			// For Next
		$page_pagination.= ' <a class="page" href="' . $_SERVER['REDIRECT_URL'] . '?page_num=' . ($current_page + 1) . $extra_p . '">See More</a>';
		}
		
		if(($current_page < ($numofpages - $range_max)) && ($numofpages > $range)){
			//$page_pagination.= ' <a class="num" title="Last" href="' . $_SERVER['REDIRECT_URL'] . '&start=' . ($numofpages - 1) . $extra_p . '">&gt;</a> ';
		}
		return $page_pagination;
	} //end if more than 1 page
}

function getImage($imageFolder,$Image,$display_inWidth,$display_inHeight,$class='',$border='',$showNoImage='') {
		$class = ( $class == "" ) ? "img" : $class;
		$ImagePath = $imageFolder."/".$Image;	
		if ( file_exists($ImagePath) && $Image != "" ) {
			list($ImageWidth, $ImageHeight) = getimagesize($ImagePath);
			if ( $ImageWidth > $display_inWidth ) {
				$ImageWidth = $display_inWidth;
			} 
			if ( $ImageHeight > $display_inHeight ) {
				$ImageHeight = $display_inHeight;
			}  
			$Imagegname=explode('.',basename($ImagePath));
			$Imgname=$Imagegname[0];
			$Image = "<img src=\"imgsize.php?&amp;constrain=1&amp;w=".$ImageWidth."&amp;h=".$ImageHeight."&amp;img=".$ImagePath."\" hspace=\"2\" vspace=\"1\" alt=\"".$Imgname."\" class=\"".$class."\" border=\"0\" />";
			return $Image;
		} else {
			if ( $showNoImage != "" ) {
				$Image = getNoImage($imageFolder,$display_inWidth,$display_inHeight,$align = '');
				return $Image;
			} else 
				return;
		}
}

function getHomeImage($imageFolder,$Image,$display_inWidth,$display_inHeight,$class='',$border='',$showNoImage='') {
		$class = ( $class == "" ) ? "img" : $class;
		$ImagePath = $imageFolder."/".$Image;	
		if ( file_exists($ImagePath) && $Image != "" ) {
			list($ImageWidth, $ImageHeight) = getimagesize($ImagePath);
			if ( $ImageWidth > $display_inWidth ) {
				$ImageWidth = $display_inWidth;
			} 
			if ( $ImageHeight > $display_inHeight ) {
				$ImageHeight = $display_inHeight;
			}  
			$Image = "<img src=\"imgsize.php?&amp;w=".$ImageWidth."&amp;h=".$ImageHeight."&amp;img=".$ImagePath."\" hspace=\"2\" vspace=\"1\" alt=\"\" class=\"".$class."\" border=\"0\" />";
		
			return $Image;
		} else {
			if ( $showNoImage != "" ) {
				$Image = getNoImage($imageFolder,$display_inWidth,$display_inHeight,$align = '');
				return $Image;
			} else 
				return;
		}
}
function getImageSlide($imageFolder,$Image,$display_inWidth,$display_inHeight,$class='',$border='',$showNoImage='') {
		$class = ( $class == "" ) ? "img" : $class;
		$ImagePath = $imageFolder."/".$Image;	
		if ( file_exists($ImagePath) && $Image != "" ) {
			list($ImageWidth, $ImageHeight) = getimagesize($ImagePath);
			if ( $ImageWidth > $display_inWidth ) {
				$ImageWidth = $display_inWidth;
			} 
			if ( $ImageHeight > $display_inHeight ) {
				$ImageHeight = $display_inHeight;
			}  
			$Image = "<img src=\"imgsize.php?&amp;constrain=1&amp;w=".$display_inWidth."&amp;h=".$display_inHeight."&amp;img=".$ImagePath."\" hspace=\"0\" vspace=\"0\" alt=\"\" class=\"".$class."\" border=\"0\" />";
		
			return $Image;
		} else {
			if ( $showNoImage != "" ) {
				$Image = getNoImage($imageFolder,$display_inWidth,$display_inHeight,$align = '');
				return $Image;
			} else 
				return;
		}
}
function getNoImage($imageFolder,$display_inWidth,$display_inHeight,$align = '') {
		if ( $align == "" ) {
			$align = "left";
		} 
		$ImagePath = $imageFolder."/noimage.jpg";	
		list($ImageWidth, $ImageHeight) = getimagesize($ImagePath);
		if ( $ImageWidth > $display_inWidth) {
			$ImageWidth = 100;
		} 
		if ( $ImageHeight > $display_inHeight ) {
			$ImageHeight = 100;
		} 
		$Image = "<img src=\"imgsize.php?&amp;constrain=1&amp;w=".$ImageWidth."&amp;h=".$ImageHeight."&amp;img=".$ImagePath."\" hspace=\"8\" vspace=\"1\" align=\"".$align."\" class=\"img\" />";
		return $Image;
}
//function for getting image extention
function getImageExtension($ImageName) {
	list($extension) = explode(".",strrev($ImageName));
	return strrev($extension);
}
function getsafefilename($folder = '',$name = '') {
	if ( file_exists($folder."/".$name) ) {
		for($i=1;$i<=400;$i++ ) {
			list($ext,$na) = explode(".",strrev($name));
			$n1=strrev(date("YmdHis"));
			$n = strrev($n1)."(".$i.")".".".strrev($ext);
			if ( file_exists($folder."/".$n) ) {
				getsafefilename($folder,$n);
			} else {
				return $n;
				break;
			}
		}
	}  else {
		list($ext,$na) = explode(".",strrev($name));
		$n1=date("YmdHis"); 
		return $n1.".".strrev($ext);
	}
}
function UploadImage($tmpName,$UploadFolder,$newfilename) {
	$target_path = $UploadFolder."/".$newfilename;
	if ( move_uploaded_file($tmpName, $target_path) ) {
		return $newfilename;	
	} else 
		return false;
}
function UploadVideo($tmpName,$UploadFolder,$newfilename,$chktype) {
	$newfilename = getsafefilename($UploadFolder,$newfilename);
	$target_path = $UploadFolder."/".$newfilename;
	
	if ( move_uploaded_file($tmpName, $target_path) ) {
		$inputvideo=$target_path;
		$tmpfilename = strrev($newfilename);		
		$tmpfilename1 = explode(".",$tmpfilename);
		$videofile = strrev($tmpfilename1[1]);
		
		$outputflv=VIDEO_UPLOAD_FLV."/".$videofile.".flv";
		exec('/usr/local/bin/ffmpeg -i ' . $inputvideo . ' -ar 22050 -ab 32 -f flv -s 400x300 ' . $outputflv);
		$ffmpegpath=$outputflv;
		$output=VIDEO_UPLOAD_IMAGE."/".$videofile."%03d.jpg";
		exec("/usr/local/bin/ffmpeg -i ".$outputflv." -an -ss 00:00:02 -t 00:00:01 -r 1 -y -s 400x300 ".$output);
		$output=VIDEO_UPLOAD_IMAGE."/".$videofile."001.jpg";
		return $newfilename;	
	} else {
		return false;
	}
}


function formatePrice($price) {
		if ( is_numeric($price) )
			return CURRENCY.number_format($price,2);
		else 
			return $price;
}


function sendHTMLMail($to,$from,$subject,$message) {
	$headers = "Reply-To: ".$from."\r\n";
	$headers .= "Return-Path: ".$from."\r\n";
	$headers .= "From: ".$from."\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	mail($to,$subject,$message, $headers);
	/*
	$headers='MIME-Version:1.0'."\r\n";
	$headers.='Content-type:text/html;charset=iso-8859-1'."\r\n";
	$headers.='From: '."Agilution Tech".'<'."info@agilutiontech.com".'>'."\r\n";
	mail($to,$subject,$message, $headers) or die("Mail Fail");*/
}
function sendHTMLMailwithReturn($to,$from,$subject,$message,$returnpath='') {
	$headers = "Reply-To: ".$from."\r\n";
	$headers .= "Return-Path: ".$from."\r\n";
	$headers .= "From: ".$from."\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	if ($returnpath!='') {
		mail($to,$subject,$message,$headers,"-f".$returnpath);
	} else {
		mail($to,$subject,$message,$headers);
	}
}
function sendPlainTextMail($to,$from,$subject,$message) {
	$headers = "FROM:".$from."\r\n";
	//$headers .= "MIME-Version: 1.0\r\n";
	//$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	mail($to,$subject,$message,$headers);
}
function getMonthOption($selected='') {
	$array = array("01"=>"January",
				   "02"=>"February",
				   "03"=>"March",
				   "04"=>"April",
				   "05"=>"May",
				   "06"=>"June",
				   "07"=>"July",
				   "08"=>"August",
				   "09"=>"September",
				   "10"=>"October",
				   "11"=>"November",
				   "12"=>"December");
	foreach($array as $key=>$value){
		$option .= "<option ";
		$option .= " value=\"".$key."\"";
		if ( $selected == $key ) {
			$option .= " selected";
		}
		$option .= " >";
		$option .= $value;
		$option .= "</option>";
	}
	return $option;
}
function getDateOption($selected="",$fromdate="",$todate="") {
				$fromdate =  ( $fromdate == "" ) ? "1" : $fromdate;
				$todate   =  ( $todate == "" ) ? "32" : $todate;
				for($i=$fromdate;$i<$todate;$i++){
					if ( strlen($i) == "1" ) $i = "0".$i;
					$option .= "<option ";
					$option .= " value=\"".$i."\"";
					if ( $selected == $i ) {
						$option .= " selected";
					}
					$option .= " >";
					$option .= $i;
					$option .= "</option>";
				}
		return $option;
}
function displayDate($date){
	if($date=="0000-00-00"){
		$dis_date = "00/00/00";
	}else {
		$dis_date=date("d-F-Y",strtotime($date));
	}
	return $dis_date;
}
function DateFormatDisplay($date){
	if($date=="0000-00-00"){
		$dis_date = "00/00/00";
	}else {
		$dis_date=date("d-F-Y h:i a",strtotime($date));
	}
	return $dis_date;
}
function insertDate($date){

	$ins_date=date("Y-m-d",strtotime($date));
	return $ins_date;
}
function sanitizeName($file_name)
{
	global $_SESSION;
	
	if($file_name == "")
	{
		return "";
	}
	
	$file_name = basename($file_name);
	$file_name = preg_replace("/[^a-zA-Z0-9\.]/", "_", $file_name);
	$file_name = preg_replace("/(_)+/", "_", $file_name);
	$file_name = time(). "_". $file_name;
	if($_SESSION['UserID'] > 0)
	{
		$file_name = $_SESSION['UserID']. "_". $file_name;
	}
	
	return $file_name;
}

function search_car($car_id){
	$sql_car = "select * from ccs_car where car_id = '".$car_id."'";
	$query_car = FetchData($sql_car);
	$make_id = $query_car['make_id'];
	$model_id = $query_car['model_id'];
	$sql_image = "select * from ccs_images where make_id = '".$make_id."' and model_id = '".$model_id."'";
	$query_image = FetchData($sql_image);
	if($query_image['image'] != "" && file_exists(CAR_UPLOAD_IMAGE."/".$query_image['image'])){
		$image = getImage(CAR_UPLOAD_IMAGE,$query_image['image'],100,100,$class='',$border='0',$showNoImage='');
	}else{
		//$image = '<img src="images/noimage.jpg" width="100" height="80" border="0" class="img"/>';
		$imageFolder = "images";
		$image = getNoImage($imageFolder,$display_inWidth,$display_inHeight,$align = '');
	}
	return $image;
}
function get_image($car_id){
	$sql_car = "select * from ccs_car where car_id = '".$car_id."'";
	$query_car = FetchData($sql_car);
	$make_id = $query_car['make_id'];
	$model_id = $query_car['model_id'];
	$sql_image = "select * from ccs_images where make_id = '".$make_id."' and model_id = '".$model_id."'";
	$query_image = FetchData($sql_image);
	if($query_image['image'] != "" && file_exists(CAR_UPLOAD_IMAGE."/".$query_image['image'])){
		$image = getImage(CAR_UPLOAD_IMAGE,$query_image['image'],250,250,$class='',$border='0',$showNoImage='');
	}else{
		//$image = '<img src="images/noimage.jpg" width="100" height="80" border="0"/>';
		$imageFolder = "images";
		$image = getNoImage($imageFolder,$display_inWidth,$display_inHeight,$align = '');
	}
	return $image;
}
function getStateDropDownList($selected_state = '') {
				$sqlState = "select * from ccs_states";
				$rowState = FetchMultipleData($sqlState);
				for($i=0; $i<count($rowState);$i++){
					$option .= "<option ";
					$option .= " value=\"".strtoupper(stripslashes($rowState[$i]['abr']))."\"";
					if ( $selected_state == strtoupper(stripslashes($rowState[$i]['abr']) )) {
						$option .= " selected = \"selected\"";
					}
					$option .= " >";
					$option .= strtoupper($rowState[$i]['abr']);
					$option .= "</option>";
				}
		return $option;
}
function multiple_upload($file,$id){
	$fh = fopen($file, "r");
	$update_cnt = 0;
	$new_cnt = 0;
	$i=0;
	while($data = fgetcsv($fh, 1000, ","))
	{
		if($i != 0){
			$make=trim($data[3]);
			if (trim($data[3]!='')) { 
			$sql_make="select * from ccs_make1 where make='".$make."'";
			if(rowCount($sql_make) == 0){	
				$postdataArray = array("make"=>'\''.$make.'\'');
				AddData("ccs_make1",$postdataArray);
				$make_id=mysql_insert_id();
			}else{
				//echo "2";
				$data_make=FetchMultipleData($sql_make);
				for($j=0;$j<count($data_make);$j++){
					$make_id=$data_make[$j]['make_id'];		
				}
			}
			}
			$model=trim($data[4]);
			if (trim($data[4]!='')) { 
			$sql_model="select * from ccs_model1 where make_id='".$make_id."' and model='".$model."'";
			if(rowCount($sql_model) == 0){	
				$postdataArray = array("make_id"=>'\''.$make_id.'\'',
									   "model"=>'\''.$model.'\'',);
				AddData("ccs_model1",$postdataArray);
				$model_id=mysql_insert_id();
			}else{
				//echo "2";
				$data_model=FetchMultipleData($sql_model);
				for($k=0;$k<count($data_model);$k++){
					$model_id=$data_model[$k]['model_id'];		
				}
			}
			}
			$date=insertDate(trim($data[15]));
			$postdataArray = array("id"=>'\''.trim($_SESSION['UserID']).'\'',
								   "stock_num"=>'\''.trim($data[0]).'\'',
								   "vin"=>'\''.trim($data[1]).'\'',
								   "year"=>'\''.trim($data[2]).'\'',
								   "make_id"=>'\''.$make_id.'\'',
								   "model_id"=>'\''.$model_id.'\'',
								   "body_style"=>'\''.trim($data[5]).'\'',
								   "mileage"=>'\''.trim($data[6]).'\'',
								   "price"=>'\''.trim($data[7]).'\'',
								   "msrp"=>'\''.trim($data[8]).'\'',
								   "type"=>'\''.trim($data[9]).'\'',
								   "exterior_color"=>'\''.trim($data[10]).'\'',
								   "trim"=>'\''.trim($data[11]).'\'',
								   "model_code"=>'\''.trim($data[12]).'\'',
								   "transmission"=>'\''.trim($data[13]).'\'',
								   "cost"=>'\''.trim($data[14]).'\'',
								   "date_arrived"=>'\''.$date.'\'',
								   "featured_equipment"=>'\''.trim($data[16]).'\'',
								   "option_group"=>'\''.trim($data[17]).'\'',
								   "fed_color"=>'\''.trim($data[18]).'\'',
								   "location"=>'\''.trim($data[19]).'\'',
								   'domain_id'=>'\''.addslashes($id).'\'');
			AddData("ccs_car1",$postdataArray);
		}
		$i++;
	}
	fclose( $fh );
}
function getYearOption($selected="",$fromyear="",$toyear="") {
				$fromyear =  ( $fromyear == "" ) ? "1990" : $fromyear;
				$toyear   =  ( $toyear == "" ) ? date("Y") + 1: $toyear;
				for($i=$fromyear;$i<=$toyear;$i++){
					$option .= "<option ";
					$option .= " value=\"".$i."\"";
					if ( $selected == $i ) {
						$option .= " selected";
					}
					$option .= " >";
					$option .= $i;
					$option .= "</option>";
				}
		return $option;
}
function DomainName($userid,$usertype,$selected=""){
	if($usertype == "user"){
		 $sqluser = "select * from ccs_usertodomain where user_id='".$userid."'";
		 $datauser=FetchMultipleData($sqluser);
			 for($j=0;$j<count($datauser);$j++){
				 $Sqldomain="select * from ccs_domains where domain_id='".$datauser[$j]['domain_id']."'";
				 $data_domain=FetchData($Sqldomain);
				 $option .= "<option ";
						$option .= " value=\"".$data_domain['domain_id']."\"";
						if ( $selected == $data_domain['domain_id'] ) {
							$option .= " selected";
						}
						$option .= " >";
						$option .= $data_domain['domain_name'];
						$option .= "</option>";
			}
	}else{
		 $Sqldomain="select * from ccs_domains where admin_id='".$userid."'";
		 $data_domain=FetchData($Sqldomain);
						$option .= "<option ";
				$option .= " value=\"".$data_domain[$j]['domain_id']."\"";
				if ( $selected == $data_domain[$j]['domain_id'] ) {
					$option .= " selected";
				}
				$option .= " >";
				$option .= $data_domain[$j]['domain_name'];
				$option .= "</option>";
	    }
	return $option;
}
function StripHTML($description){
	$document = stripslashes($description);
	$search = array('@<script[^>]*?>.*?</script>@si', // Strip out javascript
		'@<style[^>]*?>.*?</style>@siU', // Strip style tags properly
		'@<[\/\!]*?[^<>]*?>@si', // Strip out HTML tags
		'@<![\s\S]*?�[ \t\n\r]*>@', // Strip multi-line comments including CDATA
		'/\s{2,}/',
	);
	
	$text = preg_replace($search, " ", html_entity_decode($document));
	
	$pat[0] = "/^\s+/";
	$pat[2] = "/\s+\$/";
	$rep[0] = "";
	$rep[2] = " ";
	
	$text = preg_replace($pat, $rep, trim($text));
	return $text;
}
function StripHTMLTagsOnly($description){
	
	return $text;
}
function SortDesc($description,$charector="255"){
	$document = stripslashes($description);
	$search = array('@<script[^>]*?>.*?</script>@si', // Strip out javascript
		'@<style[^>]*?>.*?</style>@siU', // Strip style tags properly
		'@<[\/\!]*?[^<>]*?>@si', // Strip out HTML tags
		'@<![\s\S]*?�[ \t\n\r]*>@', // Strip multi-line comments including CDATA
		'/\s{2,}/',
	);
	
	$text = preg_replace($search, " ", html_entity_decode($document));
	
	$pat[0] = "/^\s+/";
	$pat[2] = "/\s+\$/";
	$rep[0] = "";
	$rep[2] = " ";
	
	$text = preg_replace($pat, $rep, trim($text));
	$text = substr($text,0,$charector);
	return $text."...";
}
function xml2array($contents, $get_attributes=1, $priority = 'tag') {
    if(!$contents) return array();

    if(!function_exists('xml_parser_create')) {
        //print "'xml_parser_create()' function not found!";
        return array();
    }

    //Get the XML parser of PHP - PHP must have this module for the parser to work
    $parser = xml_parser_create('');
    xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8"); # http://minutillo.com/steve/weblog/2004/6/17/php-xml-and-character-encodings-a-tale-of-sadness-rage-and-data-loss
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
    xml_parse_into_struct($parser, trim($contents), $xml_values);
    xml_parser_free($parser);

    if(!$xml_values) return;//Hmm...

    //Initializations
    $xml_array = array();
    $parents = array();
    $opened_tags = array();
    $arr = array();

    $current = &$xml_array; //Refference

    //Go through the tags.
    $repeated_tag_index = array();//Multiple tags with same name will be turned into an array
    foreach($xml_values as $data) {
        unset($attributes,$value);//Remove existing values, or there will be trouble

        //This command will extract these variables into the foreach scope
        // tag(string), type(string), level(int), attributes(array).
        extract($data);//We could use the array by itself, but this cooler.

        $result = array();
        $attributes_data = array();
        
        if(isset($value)) {
            if($priority == 'tag') $result = $value;
            else $result['value'] = $value; //Put the value in a assoc array if we are in the 'Attribute' mode
        }

        //Set the attributes too.
        if(isset($attributes) and $get_attributes) {
            foreach($attributes as $attr => $val) {
                if($priority == 'tag') $attributes_data[$attr] = $val;
                else $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
            }
        }

        //See tag status and do the needed.
        if($type == "open") {//The starting of the tag '<tag>'
            $parent[$level-1] = &$current;
            if(!is_array($current) or (!in_array($tag, array_keys($current)))) { //Insert New tag
                $current[$tag] = $result;

                if($attributes_data) $current[$tag. '_attr'] = $attributes_data;
                $repeated_tag_index[$tag.'_'.$level] = 1;

                $current = &$current[$tag];

            } else { //There was another element with the same tag name

                if(isset($current[$tag][0])) {//If there is a 0th element it is already an array
                    $current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result;
                    $repeated_tag_index[$tag.'_'.$level]++;
                } else {//This section will make the value an array if multiple tags with the same name appear together
                    $current[$tag] = array($current[$tag],$result);//This will combine the existing item and the new item together to make an array
                    $repeated_tag_index[$tag.'_'.$level] = 2;
                    
                    if(isset($current[$tag.'_attr'])) { //The attribute of the last(0th) tag must be moved as well
                        $current[$tag]['0_attr'] = $current[$tag.'_attr'];
                        unset($current[$tag.'_attr']);
                    }

                }
                $last_item_index = $repeated_tag_index[$tag.'_'.$level]-1;
                $current = &$current[$tag][$last_item_index];
            }

        } elseif($type == "complete") { //Tags that ends in 1 line '<tag />'
            //See if the key is already taken.
            if(!isset($current[$tag])) { //New Key
                $current[$tag] = $result;
                $repeated_tag_index[$tag.'_'.$level] = 1;
                if($priority == 'tag' and $attributes_data) $current[$tag. '_attr'] = $attributes_data;



            } else { //If taken, put all things inside a list(array)
                if(isset($current[$tag][0]) and is_array($current[$tag])) {//If it is already an array...

                    // ...push the new element into that array.
                    $current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result;
                    
                    if($priority == 'tag' and $get_attributes and $attributes_data) {
                        $current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data;
                    }
                    $repeated_tag_index[$tag.'_'.$level]++;

                } else { //If it is not an array...
                    $current[$tag] = array($current[$tag],$result); //...Make it an array using using the existing value and the new value
                    $repeated_tag_index[$tag.'_'.$level] = 1;
                    if($priority == 'tag' and $get_attributes) {
                        if(isset($current[$tag.'_attr'])) { //The attribute of the last(0th) tag must be moved as well
                            
                            $current[$tag]['0_attr'] = $current[$tag.'_attr'];
                            unset($current[$tag.'_attr']);
                        }
                        
                        if($attributes_data) {
                            $current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data;
                        }
                    }
                    $repeated_tag_index[$tag.'_'.$level]++; //0 and 1 index is already taken
                }
            }

        } elseif($type == 'close') { //End of tag '</tag>'
            $current = &$parent[$level-1];
        }
    }
    
    return($xml_array);
}

function getAlbumPhotos($album_id){
	$sql_albumphotos="select * from ccs_albumphotos where album_id='".$album_id."' order by photo_id desc";
	$photoscnt=rowCount($sql_albumphotos);
	$data_albumphotos=FetchMultipleData($sql_albumphotos);
	for($j=0;$j<count($data_albumphotos);$j++){
		$photo.=$data_albumphotos[$j]['photo']."~~";
		$photo_id.=$data_albumphotos[$j]['photo_id'].",";
	}
	$photo1=trim($photo,"~~");
	$photo_id1=trim($photo_id,",");
	return $photo1."|".$photo_id1;
}
function LikeButton($postid,$userid,$posttype="") {
	if ($postid!="" && $userid!="") {
		if ($posttype=="") {
			$posttype="Post";
		}
		if ($posttype=="Post") {
			$tablename = "ccs_update";
			$keyfieldname = "update_id";
		} elseif($posttype=="Photo") {
			$tablename = "ccs_albumphotos";
			$keyfieldname = "photo_id";
		}  elseif($posttype=="Advert") {
			$tablename = "ccs_advertize";
			$keyfieldname = "ad_id";
		}  elseif($posttype=="Blog") {
			$tablename = "ccs_blogs";
			$keyfieldname = "blog_id";
		}  elseif($posttype=="Classified") {
			$tablename = "ccs_Classified";
			$keyfieldname = "Classified_id";
		}  elseif($posttype=="Album") {
			$tablename = "ccs_album";
			$keyfieldname = "album_id";
		}  elseif($posttype=="Photo") {
			$tablename = "ccs_update";
			$keyfieldname = "update_id";
		}  elseif($posttype=="Music") {
			$tablename = "ccs_music";
			$keyfieldname = "music_id";
		}  elseif($posttype=="Video") {
			$tablename = "ccs_uservideo";
			$keyfieldname = "video_id";
		}  elseif($posttype=="Event") {
			$tablename = "ccs_event";
			$keyfieldname = "event_id";
		}
		$sql = "select * from ccs_post_like where post_id='".$postid."' and user_id='".$userid."' and post_type='".$posttype."' order by like_id desc";
		$sql0 = "select dummy_like from ".$tablename." where ".$keyfieldname."='".$postid."'";
		$row0 = FetchData($sql0);
		$sql1 = "select count(*) as totalliked from ccs_post_like where post_id='".$postid."' and post_type='".$posttype."'";
		$row = FetchData($sql1);
		$totalsall = rowCount($sql);
		if ($totalsall > 0) {
			$likedtext .= '<img src="images/icon-like.png" align="absmiddle"/>&nbsp;'.number_format(($row['totalliked']+$row0['dummy_like']),0).' people like this. <a href="javascript:void(0);" onclick="LikeBotton(\''.$postid.'\',\''.$posttype.'_'.$postid.'\',\''.$posttype.'\')">Unlike</a>';
		} else {
			$likedtext .= '<img src="images/icon-like.png" align="absmiddle"/>&nbsp;'.number_format(($row['totalliked']+$row0['dummy_like']),0).' people like this. <a href="javascript:void(0);" onclick="LikeBotton(\''.$postid.'\',\''.$posttype.'_'.$postid.'\',\''.$posttype.'\')">Like</a>';
		}
		return $likedtext;
	}
}
function PostComment($postid,$userid,$posttype="") {
	if ($postid!="" && $userid!="") {
		if ($posttype=="") {
			$posttype="Post";
		}
		if ($posttype=="Post") {
			$tablename = "ccs_update";
			$keyfieldname = "update_id";
		} elseif($posttype=="Photo") {
			$tablename = "ccs_albumphotos";
			$keyfieldname = "photo_id";
		}  elseif($posttype=="Advert") {
			$tablename = "ccs_advertize";
			$keyfieldname = "ad_id";
		}  elseif($posttype=="Photo") {
			$tablename = "ccs_update";
			$keyfieldname = "update_id";
		}  elseif($posttype=="Classified") {
			$tablename = "ccs_Classified";
			$keyfieldname = "Classified_id";
		}  elseif($posttype=="Album") {
			$tablename = "ccs_album";
			$keyfieldname = "album_id";
		}  elseif($posttype=="Music") {
			$tablename = "ccs_music";
			$keyfieldname = "music_id";
		}  elseif($posttype=="Blog") {
			$tablename = "ccs_blogs";
			$keyfieldname = "blog_id";
		}  elseif($posttype=="Video") {
			$tablename = "ccs_uservideo";
			$keyfieldname = "video_id";
		}  elseif($posttype=="Event") {
			$tablename = "ccs_event";
			$keyfieldname = "event_id";
		}
		$sql = "select * from ccs_post_comments where post_id='".$postid."' and post_type='".$posttype."' order by date_comment desc";
		$total_rec = rowCount($sql);
		$row = FetchData($sql);
		$comm1 = $row['comment'];
	    $comm2 = strlen($comm1);
		
		$sql1="select * from ccs_register where customer_id='".$row['user_id']."'";
		$data=FetchData($sql1);
		$likedtext = '<input type="hidden" value="'.$total_rec.'" id="totals-'.$postid.'" /><input type="hidden" value="'.$posttype.'" id="posttype-'.$postid.'" />';
		if (rowCount($sql)>0) {
			
			$likedtext .= '<div class="" id="collapsed-'.$postid.'" align="left"><img src="images/icon-s-comments.png" align="absmiddle"/> <a href="javascript: void(0)" class="commentslink"> View all '.$total_rec.' comments </a> <span id="loader-'.$postid.'">&nbsp;</span></div><div id="CommentPosted'.$postid.'"></div>';
			 					
			if ($row['user_id']==$_SESSION['UserID']) {
			$likedtext .= '<div class="commentPanel" align="left"><a href="profile.html?user_id='.$data['customer_id'].'" style="padding:0;margin:0;"><img src="timthumb.php?src='.UPLOAD_IMAGE.'/'.$data['image'].'&amp;h=35&amp;w=35&amp;zc=1" class="CommentImg" style="float:left;" alt="" /></a>';
			
			if($comm2 < 30) {
			$likedtext .= '<div align="right" style="margin-bottom:-13px;">
			<a href="#" class="#" onclick="del_data1('.$row['like_id'].');"><img src="images/delete.png" hspace="5" border="0" align="bottom" style="margin-right:-3px;"/></a></div>
			
			<label class="postedComments"><a href="profile.html?user_id='.$data['customer_id'].'" style="padding:0; margin:0;">'.$data['fname'].' '.$data['lname'].'</a>: '. stripcslashes($row['comment']).'</label><br/>
			
			<span style="margin-left:11px; color:#EAEAEA; font-size:11px"> '.DateFormatDisplay($row['date_comment']).' </span>
			</div>';
			} else {
			$likedtext .= '<div align="right" style="margin-bottom:-13px;">
			<a href="#" class="#" onclick="del_data1('.$row['like_id'].');"><img src="images/delete.png" hspace="5" border="0" align="bottom" style="margin-right:-3px;"/></a></div>
			
			<label class="postedComments1"><a href="profile.html?user_id='.$data['customer_id'].'" style="padding:0; margin:0;">'.$data['fname'].' '.$data['lname'].'</a>: '. stripcslashes($row['comment']).'</label><br/>
			
			<span style="margin-left:35px; color:#EAEAEA; font-size:11px; width:100px;"> '.DateFormatDisplay($row['date_comment']).' </span>
			</div>';
			}
			
			}
		} else {
			$likedtext .= '<div class="" align="left"><img src="images/icon-s-comments.png" align="absmiddle"/> Write a Comments</div>';
		}
		$likedtext .= '<div class="commentPanel"><form name="frmcmment'.$postid.'" id="frmcmment'.$postid.'" class="commentform" action="action.php" method="post" enctype="multipart/form-data">
		<input type="hidden" name="do" value="AddComments" />
		<input type="hidden" name="post_type" value="'.$posttype.'" />
		<input type="hidden" name="post_id" value="'.$postid.'" />
		<input type="text" name="comments" id="comments" class="textbox autoclear required" value="Write a comment" style="width:325px;" />
		<input style="background-color:#201230;border:0"   type="button" id="submit" name="submit" value="" onclick="Validate_form(\'frmcmment'.$postid.'\')" />
		</form>
		</div>
		';
		return $likedtext;
	}
}

function GetName($userid,$show=''){
	$sql_msg="select * from ccs_register where customer_id='".$userid."'";
	$data_msg=FetchData($sql_msg);
	if ($show=='') {
		$name=$data_msg['fname']." ".$data_msg['lname'];
	}
	if ($show=='fname') {
		$name=$data_msg['fname'];
	}
	if ($show=='lname') {
		$name=$data_msg['lname'];
	}
	return $name;
}

function GetProfilePic($userid){
	$sql_msg="select * from ccs_register where customer_id=".$userid;
	$data_msg=FetchData($sql_msg);
	$image=$data_msg['image'];
	return $image;
}

function GetStatus($userid){
	$sql_msg="select * from ccs_register where customer_id='".$userid."'";
	$data_msg=FetchData($sql_msg);
	return $data_msg['online'];
}
function FindFriendID($userid) {
 $sql_findfriend="select * from ccs_friend where from_id='".$userid."' and status=1";
 $data_findfriend=FetchMultipleData($sql_findfriend);
 for($j=0;$j<count($data_findfriend);$j++){
		$friend_id.=$data_findfriend[$j]['to_id'].",";
	}
	$friend_id1=trim($friend_id,",");
	return $friend_id1;
}

function StripHTMLTagsOnlyTo($description){
	$text = str_replace("<","&lt;",$description);
	$text = str_replace("<","&gt;",$text);
	return $text;
}?>
