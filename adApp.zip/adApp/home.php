<?php
	include("header.php");
?>
        <!-- /.aside -->
        <section id="content">
          <section class="hbox stretch">
            <section>
              <section class="vbox">
                <section class="scrollable padder">              
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="panel b-a">
                        <div class="row m-n">
                          <div class="col-md-6 b-b b-r">
                            <a href="customer.php" class="block padder-v hover">
                              <span class="i-s i-s-2x pull-left m-r-sm">
                                <i class="i i-hexagon2 i-s-base text-danger hover-rotate"></i>
                                <i class="i i-users2 i-sm text-white"></i>
                              </span>
                              <span class="clear">
                                <?php
									$res1 = FetchData("select count(*) as total from adsimg");
								?>
                                <span class="h3 block m-t-xs text-danger"><?php echo $res1["total"]; ?></span>
                                <small class="text-muted text-u-c">Total Ads</small>
                              </span>
                            </a>
                          </div>
                          <div class="col-md-6 b-b">
                            <a href="order.php" class="block padder-v hover">
                              <span class="i-s i-s-2x pull-left m-r-sm">
                                <i class="i i-hexagon2 i-s-base text-success-lt hover-rotate"></i>
                                <i class="i i-alarm i-sm text-white"></i>
                              </span>
                              <span class="clear">
								<?php
									$res2 = FetchData("select count(*) as total from adscnt where date(datetime) = CURDATE()");
								?>
                                <span class="h3 block m-t-xs text-success"><?php echo $res2["total"]; ?></span>
                                <small class="text-muted text-u-c">Today Viewer</small>
                              </span>
                            </a>
                          </div>
                          <!--div class="col-md-6 b-b b-r">
                            <a href="#" class="block padder-v hover">
                              <span class="i-s i-s-2x pull-left m-r-sm">
                                <i class="i i-hexagon2 i-s-base text-info hover-rotate"></i>
                                <i class="i i-location i-sm text-white"></i>
                              </span>
                              <span class="clear">
                                <span class="h3 block m-t-xs text-info">25 <span class="text-sm">m</span></span>
                                <small class="text-muted text-u-c">location</small>
                              </span>
                            </a>
                          </div>
                          <div class="col-md-6 b-b">
                            <a href="#" class="block padder-v hover">
                              <span class="i-s i-s-2x pull-left m-r-sm">
                                <i class="i i-hexagon2 i-s-base text-primary hover-rotate"></i>
                                <i class="i i-alarm i-sm text-white"></i>
                              </span>
                              <span class="clear">
                                <span class="h3 block m-t-xs text-primary">9:30</span>
                                <small class="text-muted text-u-c">Meeting</small>
                              </span>
                            </a>
                          </div-->
                        </div>
                      </div>
                    </div>
                    
                    <div class="col-sm-6">
                      <div class="panel b-a">
                        <div class="row m-n">
                          <div class="col-md-6 b-b b-r">
                            <a href="category.php" class="block padder-v hover">
                              <span class="i-s i-s-2x pull-left m-r-sm">
                                <i class="i i-hexagon2 i-s-base text-info hover-rotate"></i>
                                <i class="i i-layer i-sm text-white"></i>
                              </span>
                              <span class="clear">
                                <?php
									$res3 = FetchData("select count(*) as total from adscnt");
								?>
                                <span class="h3 block m-t-xs text-info"><?php echo $res3["total"]; ?></span>
                                <small class="text-muted text-u-c">Total Viewer</small>
                              </span>
                            </a>
                          </div>
                          <div class="col-md-6 b-b">
                            <a href="product.php" class="block padder-v hover">
                              <span class="i-s i-s-2x pull-left m-r-sm">
                                <i class="i i-hexagon2 i-s-base text-primary hover-rotate"></i>
                                <i class="i i-layer2 i-sm text-white"></i>
                              </span>
                              <span class="clear">
                                <?php
									$res4 = FetchMultipleData("select count(deviceid) from adscnt group by deviceid");
								?>
                                <span class="h3 block m-t-xs text-primary"><?php echo sizeof($res4); ?></span>
                                <small class="text-muted text-u-c">Total Users</small>
                              </span>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
					
				
                <section class="scrollable padder">              
                  
                 
                  <section class="panel panel-default">
					  <header class="panel-heading">
						Today Viewer
					</header>
                
                <div class="table-responsive">
                  <table class="table table-striped b-t b-light" data-ride="datatablesHome">
                    <thead>
                      <tr>
                        <th width="100">Sr</th>
                        <th>Device Id</th>
                        <th>Time</th>
                        <th>Ads</th>
                      </tr>
                    </thead>
                    
                    <tbody>
						
                    </tbody>
                  </table>
                </div>
                
                
                </section>
              </section>
            </section>
<?php
	include("footer.php");
?>
