<?php
	session_start();
	error_reporting(0);
	include("config.php");
	include("functions_mysql.php");
?>
<!DOCTYPE html>
<html lang="en" class="app">
<head>  
  <meta charset="utf-8" />
  <title>Ad Admin</title>
  <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="css/animate.css" type="text/css" />
  <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="css/icon.css" type="text/css" />
  <link rel="stylesheet" href="css/font.css" type="text/css" />
  <link rel="stylesheet" href="css/app.css" type="text/css" />  
  <link rel="stylesheet" href="js/datatables/datatables.css" type="text/css"/>
  <link rel="stylesheet" href="js/calendar/bootstrap_calendar.css" type="text/css" />
  <link rel="SHORTCUT ICON" href="images/logo.png" />
  <!--[if lt IE 9]>
    <script src="js/ie/html5shiv.js"></script>
    <script src="js/ie/respond.min.js"></script>
    <script src="js/ie/excanvas.js"></script>
  <![endif]-->
</head>
<body class="">
  <section class="vbox">
    <header class="bg-danger header header-md navbar navbar-fixed-top-xs box-shadow">
      <div class="navbar-header aside dk">
        <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav">
          <i class="fa fa-bars"></i>
        </a>
        <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".user">
          <i class="fa fa-cog"></i>
        </a>
      </div>
      <a href="index.php" class="navbar-brand">
	     <span class="hidden-nav-xs">Ad Admin</span>
	  </a>
      <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user user">
        <li class="dropdown">
          <label class="dropdown-toggle" data-toggle="dropdown" style="cursor:pointer;width:50px;margin-top:15px;">
            <span class="pull-left">
              <i class="i i-user3 i-2x text-white"></i>
            </span>
          </label>
          <ul class="dropdown-menu animated fadeInRight">            
            <!--li>
              <span class="arrow top"></span>
              <a href="#">Settings</a>
            </li>
            <li>
              <a href="profile.html">Profile</a>
            </li-->
            <!--li>
              <a href="#">
                <span class="badge bg-danger pull-right">5</span>
                Order
              </a>
            </li-->
            <li>
              <a href="changepassword.php">Change Password</a>
            </li>
            <li class="divider"></li>
            <li>
              <a href="action.php?do=logout" >Logout</a>
            </li>
          </ul>
        </li>
      </ul>      
    </header>
    <section>
      <section class="hbox stretch">
        <!-- .aside -->
        <aside class="bg-light lt b-r b-light aside hidden-print" id="nav">          
          <section class="vbox">
            <section class="w-f scrollable">
              <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="10px" data-railOpacity="0.2">
                <!-- nav -->                 
                <nav class="nav-primary hidden-xs">
                  <!--div class="text-muted text-sm hidden-nav-xs padder m-t-sm m-b-sm">Start</div-->
                  <ul class="nav nav-main" data-ride="collapse">
                    <li  class="active">
                      <a href="home.php" class="auto active">
                        <i class="i i-statistics icon">
                        </i>
                        <span class="font-bold">Dashboard</span>
                      </a>
                    </li>
                     <li  class="active">
                      <a href="adimages.php" class="auto">
                        <i class="i i-users2 icon">
                        </i>
                        <span class="font-bold">Ad Images</span>
                      </a>
                    </li>
                    <li  class="active">
                      <a href="logs.php" class="auto">
                        <i class="i i-layer icon">
                        </i>
                        <span class="font-bold">Log</span>
                      </a>
                    </li>
                     
                  </ul>
                </nav>
                <!-- / nav -->
              </div>
            </section>
            
            <footer class="footer hidden-xs no-padder text-center-nav-xs">
              <!--a href="modal.lockme.html" data-toggle="ajaxModal" class="btn btn-icon icon-muted btn-inactive pull-right m-l-xs m-r-xs hidden-nav-xs">
                <i class="i i-logout"></i>
              </a-->
              <a href="#nav" data-toggle="class:nav-xs" class="btn btn-icon icon-muted btn-inactive m-l-xs m-r-xs active">
                <i class="i i-circleleft text"></i>
                <i class="i i-circleright text-active"></i>
              </a>
            </footer>
          </section>
        </aside>
