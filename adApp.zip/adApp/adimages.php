<?php
	include("header.php");
?>
        <!-- /.aside -->
        <section id="content">
          <section class="hbox stretch">
            <section>
              <section class="vbox">
                <section class="scrollable padder">              
                  
                  <div class="col-sm-6">
                      <h3 class="m-b-xs text-black">Ad Images</h3>
                      <small><br /></small>
                    </div>
                  <div class="col-sm-6 text-right text-left-xs m-t-md">
                      <a href="addadimage.php" class="btn btn-icon b-2x btn-danger btn-rounded hover"><i class="i i-plus2 i-1x hover-rotate"></i></a>
                    </div>
                  <div class="row">
                   
                   
                    
                  </div>
                  <section class="panel panel-default">
                
                
                <div class="table-responsive">
                  <table class="table table-striped b-t b-light" data-ride="datatablesAdImages">
                    <thead>
                      <tr>
                        <th width="100">Sr</th>
                        <th>Title</th>
                        <th width="30"></th>
                      </tr>
                    </thead>
                    
                    <tbody>
                     
                    </tbody>
                  </table>
                </div>
                
              </section>
                </section>
              </section>
            </section>
<?php
	include("footer.php");
?>
