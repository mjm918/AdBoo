<?php
	include("header.php");
?>
        <!-- /.aside -->
        <section id="content">
          <section class="hbox stretch">
            <section>
              <section class="vbox">
                <section class="scrollable padder">              
                   <div class="col-sm-6">
                      <h3 class="m-b-xs text-black">Add Images</h3>
                      <small><br /></small>
                    </div>
                    
                  <div class="col-sm-6 text-right text-left-xs m-t-md">
					  <a href="adimages.php" class="btn btn-icon b-2x btn-danger btn-rounded hover"><i class="i i-list i-1x hover-rotate"></i></a>
                     </div>
                  <div class="row">
                    
                  </div>
                 <div class="col-sm-6">
                  <form action="action.php" method="post" data-validate="parsley" enctype="multipart/form-data">
					<input type="hidden" name="do" value="addimages">
                    <section class="panel panel-default">
                     
                      <div class="panel-body">
                        <p class="text-muted">Please fill the information to continue</p>
                        <div class="form-group">
                          <label>Title</label>
                          <input type="text" name="title" class="form-control" placeholder="Title" data-required="true">                        
                        </div>
                        <div class="form-group">
                          <label>Image</label>
                          <input type="file" name="photo" class="form-control" placeholder="Image" data-required="true">                        
                        </div>
                      </div>
                      <footer class="panel-footer text-right bg-light lter">
                        <button type="submit" class="btn btn-danger btn-s-xs">Add</button>
                      </footer>
                    </section>
                  </form>
                </div>		
                </section>
              </section>
            </section>
    <?php
	include("footer.php");
?>
